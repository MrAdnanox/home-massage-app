import https from 'https';

https.get('https://homemassageapp.ma/wp-json/wp/v2/service_app?per_page=1', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    try {
      const json = JSON.parse(data);
      console.log("SUCCESS service_app:", JSON.stringify(json[0]).substring(0, 500));
    } catch (e) {
      console.log("ERROR parsing service_app:", e.message);
    }
  });
}).on('error', (e) => {
  console.error(e);
});

https.get('https://homemassageapp.ma/wp-json/wp/v2/services-app?per_page=1', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    try {
      const json = JSON.parse(data);
      console.log("SUCCESS services-app:", JSON.stringify(json[0]).substring(0, 500));
    } catch (e) {
      console.log("ERROR parsing services-app:", e.message);
    }
  });
}).on('error', (e) => {
  console.error(e);
});
