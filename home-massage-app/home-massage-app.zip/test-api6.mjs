import https from 'https';

https.get('https://homemassageapp.ma/wp-json/wp/v2/service_app?per_page=100', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    try {
      const json = JSON.parse(data);
      console.log("Total items:", json.length);
      if (json.length > 0) {
        console.log("Item 0:", JSON.stringify(json[0], null, 2));
      }
    } catch (e) {
      console.log("ERROR parsing service_app:", e.message);
    }
  });
}).on('error', (e) => {
  console.error(e);
});
