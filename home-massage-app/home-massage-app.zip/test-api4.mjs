import https from 'https';

https.get('https://homemassageapp.ma/wp-json/wp/v2/service?per_page=100', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    try {
      const json = JSON.parse(data);
      console.log("Total items in service:", json.length);
      if (json.length > 0) {
        console.log("First item keys:", Object.keys(json[0]));
        console.log("First item is_sticky:", json[0].is_sticky);
      }
    } catch (e) {
      console.log("ERROR parsing service:", e.message);
    }
  });
}).on('error', (e) => {
  console.error(e);
});
