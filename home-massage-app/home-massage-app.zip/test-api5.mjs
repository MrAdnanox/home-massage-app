import https from 'https';

https.get('https://homemassageapp.ma/wp-json/wp/v2/services-app?per_page=100', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    console.log("services-app response:", data.substring(0, 500));
  });
}).on('error', (e) => {
  console.error(e);
});
