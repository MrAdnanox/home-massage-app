import https from 'https';

https.get('https://homemassageapp.ma/wp-json/wp/v2/service_app?per_page=1', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    try {
      const json = JSON.parse(data);
      console.log("Keys:", Object.keys(json[0]));
      console.log("is_sticky:", json[0].is_sticky);
      console.log("sticky:", json[0].sticky);
      console.log("meta:", json[0].meta);
      console.log("acf:", json[0].acf);
    } catch (e) {
      console.log("ERROR parsing service_app:", e.message);
    }
  });
}).on('error', (e) => {
  console.error(e);
});
