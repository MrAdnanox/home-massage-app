import https from 'https';

https.get('https://homemassageapp.ma/wp-json/wp/v2/service_app?per_page=100', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    try {
      const json = JSON.parse(data);
      console.log("Total items:", json.length);
      const stickyItems = json.filter(item => item.is_sticky || item.sticky || (item.meta && item.meta._mpe2025_is_sticky));
      console.log("Sticky items found:", stickyItems.length);
      if (json.length > 0) {
        console.log("First item keys:", Object.keys(json[0]));
        console.log("First item is_sticky:", json[0].is_sticky);
      }
    } catch (e) {
      console.log("ERROR parsing service_app:", e.message);
    }
  });
}).on('error', (e) => {
  console.error(e);
});
